<?php

$con = mysqli_connect("localhost", "root", "", "db_shreddersbay");

if (!$con) {
    die('Could not connect: ' . mysqli_connect_error());
}
